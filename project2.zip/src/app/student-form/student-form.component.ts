import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { student } from '../student';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  StudentForm =new FormGroup({
    StudentName : new FormControl('',[ Validators.pattern('[a-zA-Z ]*'), Validators.required ]),
    StudentPhoneNo: new FormControl('',[Validators.required, Validators.minLength(10),Validators.maxLength(10)]),
    StudentEmail : new FormControl('',[Validators.required, Validators.email])
  })
  
  @Output() newItemEvent = new EventEmitter<student>();

  addNewItem(fg : student) {
      this.newItemEvent.emit(fg);
      // console.log(fg)
    }
}
