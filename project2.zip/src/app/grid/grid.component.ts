import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {
  

  constructor(private route: ActivatedRoute) { }
 
  @Input() data ="";
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.data = params['items'];
    });
    
  }

  

}
