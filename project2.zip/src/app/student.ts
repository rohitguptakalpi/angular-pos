export interface student {
    StudentEmail: string
    StudentName: string
    StudentPhoneNo: string
}
