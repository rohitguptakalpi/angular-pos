import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GridComponent } from './grid/grid.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SecondComponentComponent } from './second-component/second-component.component';

const routes: Routes = [
  {path:'',redirectTo:'/grid', pathMatch:'full'},
  {path:'grid', component:GridComponent},
  {path:'second', component:SecondComponentComponent},
  {path:'**', component:PageNotFoundComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
