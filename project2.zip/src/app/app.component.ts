import { Component } from '@angular/core';
import { student } from './student';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'project2';


  items = []

  addItem(person: student) {
    const ch = (p) => p.StudentPhoneNo === person.StudentPhoneNo;

    if (this.items.some(ch)=== false){
    this.items.push(person);
    console.log(person);
    }
    else{
      alert("registered phone no. is already exist")
    }
    
    // console.log(this.items)
  }


}
